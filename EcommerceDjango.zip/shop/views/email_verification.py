from django.views import View
from django.contrib.auth.hashers import check_password, make_password
from shop.models import User
from shop.utils.email_sender import sendEmail
from django.shortcuts import render, redirect
from django.shortcuts import HttpResponse

import random
import math

def send_otp(request):
    name = request.POST.get('name')
    email = request.POST.get('email')
    otp = math.floor(random.random() * 10000000)
    print('OTP', otp)
    html = f'''
        <h4>Hello {name},<h4>
        </br>
        <p>Your Verification code is <b>{otp}</b></p>
        </br>
        <p>if you did not requested verification code, you can ignore this Email</p>
    '''
    print(name, email)
    if name and email:
        response = sendEmail(name=name, email=email, htmlContent=html, subject='Verify Email')
        print(response.json())
        print(response.status_code)

        try:
            if (response.status_code == 200):
                request.session['verification-code'] = otp
                return HttpResponse("{'message':'Success'}", status=200)

            else:
                return HttpResponse(status=400)

        except Exception as e:
            print(e)


def verifyCode(request):
    code = request.POST.get('code')

    otp = request.session.get('verification-code')
    print('code', code)
    print('otp', otp)
    if str(otp) == code:
        return HttpResponse({'message': 'success'}, status=200)
    else:
        return HttpResponse(status=400)
