from django.views import View
from django.contrib.auth.hashers import check_password, make_password
from shop.models import User
from django.shortcuts import render, redirect, HttpResponse
from shop.models import User, Product, ProductImages, Payment
from django.db.models import Q

def productDetails(request, product_id):
    products = Product.objects.get(id=product_id)
    images = ProductImages.objects.filter(product=product_id)
    can_download = False
    try:
        session_user = request.session.get('user')
        if session_user:
            user_id = session_user.get('id')
            user = User(id=user_id)
            payment =Payment.objects.get( ~Q(status="Failed"),product=products,user=user)
            if len(payment) != 0:
                can_download = True


    except:
        pass
    return render(request, 'product_details.html', {'product': products,
                                                    'images': images,
                                                    'can_download':can_download})
    # return HttpResponse(f'<h1 class="display-1">{product.name}</h1>')
