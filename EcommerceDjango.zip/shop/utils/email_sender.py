import requests
from download_products.settings import EMAIL_SERVICE_ENDPOINT, EMAIL_SENDER_NAME, EMIAL_SENDER_EMAIL, EMAIL_API_KEY

import json


def sendEmail(name, email, subject, htmlContent):
    # payload = {
    #     "sender": {
    #         "name": EMAIL_SENDER_NAME,
    #         "email": EMIAL_SENDER_EMAIL
    #     },
    #     "to": [
    #         {
    #             "email": email,
    #             'name': name
    #
    #         }
    #     ],
    #     'replyTo': {
    #         "email": EMIAL_SENDER_EMAIL,
    #         "name": EMAIL_SENDER_NAME
    #     },
    #     "htmlContent": htmlContent,
    #     'subject': subject
    # }
    #
    # headers = {
    #     'accept': "application/json",
    #     'content-type': "application/json",
    #     'api-key': EMAIL_API_KEY
    # }
    #
    # response = requests.request("POST",
    #                             EMAIL_SERVICE_ENDPOINT,
    #                             data=json.dumps(payload),
    #                             headers=headers)

    return requests.post(
        "https://api.mailgun.net/v3/sandboxec6bbc2ac952481b968f7205ceaf8a76.mailgun.org/messages",
        auth=("api", "0666672c33e84a242a1d1ea1ac1d4ea8-07bc7b05-1221355a"),
        data={"from": "InfogenLabs <Akshay@sandboxec6bbc2ac952481b968f7205ceaf8a76.mailgun.org>",
              "to": ["adhomse99@gmail.com"],
              "subject": subject,
              "html": htmlContent})

#print(sendEmail("Akshay","adhomse99@gmail.com","Testing Email","<h1>Hello WOrld</h1>"))